package Ebiiling.Project;


// READ-ME ....

//       ADMIN LOGIN DATA : 

// Admin username  = Admin
// Admin password = password

//       USER LOGIN DATA : 

// Takes anything without special charaters as inputs


//                                      ___Taahier...