package Ebiiling.Project;

public class ExistingUserData {
    private static final String USER_1_DATA = "\n      -> Name=Sha \n      -> Ebill_Number=321123456789 \n      -> Phases_Connection=2 \n      -> This_Month_Bill=1200.0 \n      -> Pending_Bill=350.0";
    private static final String USER_2_DATA = "\n      -> Name=Tharun \n      -> Ebill_Number=334321123412 \n      -> Phases_Connection=3 \n      -> This_Month_Bill=300.0 \n      -> Pending_Bill=0.0";
    private static final String USER_3_DATA = "\n      -> Name=Sundar \n      -> Ebill_Number=347654890112 \n      -> Phases_Connection=2 \n      -> This_Month_Bill=2300.0 \n      -> Pending_Bill=200.0";
    private static final String USER_4_DATA = "\n      -> Name=Ismail \n      -> Ebill_Number=359465783456 \n      -> Phases_Connection=2 \n      -> This_Month_Bill=620.0 \n      -> Pending_Bill=100.0";
    private static final String ADMIN_DATA = "admin data";

    private static final String ADMIN_USERNAME = "Admin";
    private static final String ADMIN_PASSWORD = "password";

    public static String getUser1Data() {
        return USER_1_DATA;
    }

    public static String getUser2Data() {
        return USER_2_DATA;
    }

    public static String getUser3Data() {
        return USER_3_DATA;
    }

    public static String getUser4Data() {
        return USER_4_DATA;
    }

    public static String getAdminData() {
        return ADMIN_DATA;
    }

    public static String getAdminUsername() {
        return ADMIN_USERNAME;
    }

    public static String getAdminPassword() {
        return ADMIN_PASSWORD;
    }
}

