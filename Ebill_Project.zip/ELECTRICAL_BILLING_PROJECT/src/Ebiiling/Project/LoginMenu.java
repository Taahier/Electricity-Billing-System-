package Ebiiling.Project;
import java.util.Scanner;



public class LoginMenu {

    static void handleLoginChoice(Scanner scanner) {
    	
    	System.out.println();
    	System.out.println(" -> Performing Login...");


        displayUserLoginMenu(scanner);
    }

    static void performUserRegistration(Scanner scanner) {
    	System.out.println();
    	System.out.println("Performing Registration...");
    	
		System.out.println();
		System.out.println("**********************************************************");
		System.out.println("*-------------------- REGISTRATION ----------------------*");
		System.out.println("**********************************************************");
		System.out.println();

        UserData userData = new UserData();
        userData.captureUserData();
        userData.displayUserData();
    }

    private static void displayUserLoginMenu(Scanner scanner) {
        while (true) {
    		System.out.println();
    		System.out.println("**********************************************************");
    		System.out.println("*------------------------ LOGIN -------------------------*");
    		System.out.println("**********************************************************");
    		System.out.println();
            System.out.println(" -> Select an option : ");
            System.out.println();
            System.out.println(" 1) Admin Login");
            System.out.println(" 2) User Login");
            System.out.println(" 3) Main Menu");
            System.out.println();

            System.out.print(" -> Enter your choice : ");
            String choice = scanner.nextLine().toLowerCase();

            switch (choice) {
                case "admin login":
                case "1":
                    performAdminLogin(scanner);
                    break;
                case "user login":
                case "2":
                    performUserLogin(scanner);
                    break;
                case "main menu":
                case "3":
                    // Return to the main menu
                    return;
                default:
                    System.err.println("Invalid choice. Please select either Admin Login, User Login, or Main Menu.");
            }
        }
    }

    private static void performAdminLogin(Scanner scanner) {
    	
    	System.out.println();
    	
    	System.out.println("*---- ADMIN ----*");
    	System.out.println();
    	
        System.out.print(" -> Enter Admin Username : ");
        String adminUsername = scanner.nextLine().trim();

        System.out.print(" -> Enter Admin Password : ");
        String adminPassword = scanner.nextLine().trim();

        if (adminUsername.equals(ExistingUserData.getAdminUsername()) && adminPassword.equals(ExistingUserData.getAdminPassword())) {
            System.out.println();
        	System.out.println(" -> Admin login successful.");
            
            System.out.println();
            System.out.println("*********************");
            System.out.println("*------ ADMIN ------*");
            System.out.println("*********************");
            System.out.println();

            // Display user data when Admin logs in
            System.out.println(" -> Customer Data :");
            System.out.println();
            System.out.println(" 1) Customer 1");
            System.out.println(" 2) Customer 2");
            System.out.println(" 3) Customer 3");
            System.out.println(" 4) Customer 4");

            // Ask admin to choose a user
            String userChoice = getUserChoice(scanner);
            displayUserData(userChoice);
        } else {
            System.err.println("Invalid credentials. Returning to the login menu.");
        }
    }

    private static void performUserLogin(Scanner scanner)
    {
        System.out.println();
        System.out.println("*********************");
        System.out.println("*------ LOGIN ------*");
        System.out.println("*********************");
        System.out.println();
    	
        System.out.print(" -> Enter User Username: ");
        String userUsername = scanner.nextLine().trim();

        System.out.print(" -> Enter User Password: ");
        @SuppressWarnings("unused")
		String userPassword = scanner.nextLine().trim();


        System.out.println(" -> Performing login for " + userUsername);


    }

    private static String getUserChoice(Scanner scanner) {
    	System.out.println();
        System.out.print(" -> Choose a Customer : ");
        return scanner.nextLine().trim();
    }

    private static void displayUserData(String userChoice) {
        switch (userChoice) {
            case "1":
            	System.out.println();
                System.out.println(" -> User 1 Data : " + ExistingUserData.getUser1Data());
                break;
            case "2":
            	System.out.println();
                System.out.println(" -> User 2 Data : " + ExistingUserData.getUser2Data());
                break;
            case "3":
            	System.out.println();
                System.out.println(" -> User 3 Data : " + ExistingUserData.getUser3Data());
                break;
            case "4":
            	System.out.println();
                System.out.println(" -> User 4 Data : " + ExistingUserData.getUser4Data());
                break;
            default:
                System.err.println("Invalid user choice.");
        }
    }
}