package Ebiiling.Project;


import java.util.Scanner;

class CalculateEbill {
    public static void calculateEbill() {
        double tariff = 3.5; 
        double units = 0; 
        double pendingBill = 0;

        Scanner scanner = new Scanner(System.in);

       
        units = captureAndValidateUnits(scanner);

       
        pendingBill = captureAndValidatePendingBill(scanner);

        // Calculate the bills
        double bill;
        if (units <= 200) {
            bill = units * tariff + pendingBill;
        } else {
            bill = 200 * tariff + (units - 200) * 5 + pendingBill;
        }

        System.out.println();
        System.out.println(" -> Calculated E-Bill : Rs. " + bill);
        System.out.println();
    }

    private static double captureAndValidateUnits(Scanner scanner) {
        double units = 0;

        while (true) {
        	
    		System.out.println();
    		System.out.println("**********************************************************");
    		System.out.println("*----------------- E-BILL CALCULATION -------------------*");
    		System.out.println("**********************************************************");
    		System.out.println();
            System.out.print(" -> Enter Units Consumed : ");
            try {
                units = Double.parseDouble(scanner.nextLine());
                if (units >= 0) {
                    return units;
                } else {
                    System.err.println("Invalid input. Enter a valid Units Consumed.");
                }
            } catch (NumberFormatException e) {
                System.err.println("Invalid input. Enter a valid Units Consumed.");
            }
        }
    }

    private static double captureAndValidatePendingBill(Scanner scanner) {
        double pendingBill = 0;

        while (true) {
            System.out.print(" -> Enter Pending Bill Amount : ");
            try {
                pendingBill = Double.parseDouble(scanner.nextLine());
                if (pendingBill >= 0) {
                    return pendingBill;
                } else {
                    System.err.println("Invalid input. Enter a valid Pending Bill Amount.");
                }
            } catch (NumberFormatException e) {
                System.err.println("Invalid input. Enter a valid Pending Bill Amount.");
            }
        }
    }
}