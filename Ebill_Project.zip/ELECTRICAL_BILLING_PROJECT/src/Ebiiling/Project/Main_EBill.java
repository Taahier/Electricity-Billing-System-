package Ebiiling.Project;



import java.util.Scanner;

public class Main_EBill {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            
    		System.out.println();
    		System.out.println("**********************************************************");
    		System.out.println("*------------ WELCOME to the EBilling System ------------*");
    		System.out.println("**********************************************************");
    		System.out.println();

    		System.out.println(" -> Would you like to enter the EBilling System ? ");
    		System.out.print(" -> Yes/1  Or  No/0 : ");
    		
            String confirmation = scanner.nextLine().toLowerCase();

            if ("yes".equals(confirmation) || "1".equals(confirmation)) {

                while (true) {
                    MainMenu.displayMainMenu();
                    String choice = MainMenu.getChoice(scanner);
                    MainMenu.handleMainMenuChoice(choice, scanner);
                }
            } else if ("no".equals(confirmation) || "0".equals(confirmation)) {
        		System.out.println();
        		System.out.println("**********************************************************");
        		System.out.println("*----------------- EXITING THE SYSTEM -------------------*");
        		System.out.println("*-----------------  HAVE A NICE DAY ! -------------------*");
        		System.out.println("**********************************************************");
        		System.out.println();
        		
            } else {
                System.err.println("Invalid input. Exiting the eBilling app.");
            }
        }
    }
}
