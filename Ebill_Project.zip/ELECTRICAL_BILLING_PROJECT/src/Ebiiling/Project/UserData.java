package Ebiiling.Project;

import java.util.Scanner;

public class UserData {
    private String customerName;
    private String ebillNumber;
    private int numberOfPhases;
    private String password;

    public void captureUserData() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println(" -> Enter Details : ");
        System.out.println();;

        this.customerName = captureAndValidateInput(scanner, " -> Enter Customer Name : ", "[a-zA-Z ]+");
        this.ebillNumber = captureAndValidateInput(scanner, " -> Enter eBill Number (12 digits starting with 34 or 35): ", "[34][0-9]{11}");
        this.numberOfPhases = Integer.parseInt(captureAndValidateInput(scanner, " -> Enter Number of Phases (2 or 3): ", "[23]"));
        this.password = captureAndValidateInput(scanner, " -> Enter Password (8 characters with letters and numbers): ", "[a-zA-Z0-9]{8}");
    }

    public void displayUserData() {
        System.out.println("\n ---- User Registration Details ----");
        System.out.println(" -> Customer Name : " + this.customerName);
        System.out.println(" -> eBill Number : " + this.ebillNumber);
        System.out.println(" -> Number of Phases : " + this.numberOfPhases);
        System.out.println(" -> Password : " + this.password);
    }

    private String captureAndValidateInput(Scanner scanner, String prompt, String regex) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            if (input.matches(regex)) {
                return input;
            } else {
                System.err.println("Invalid input. Please follow the specified format.");
            }
        }
    }
}

