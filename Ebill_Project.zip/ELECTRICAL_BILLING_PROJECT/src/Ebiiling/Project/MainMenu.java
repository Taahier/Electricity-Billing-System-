package Ebiiling.Project;

import java.util.Scanner;


public class MainMenu {
    private static final String YES_OPTION = "yes";
    private static final String NO_OPTION = "no";

    static void displayMainMenu() {
		System.out.println();
		System.out.println("**********************************************************");
		System.out.println("*---------------------- MAIN MENU -----------------------*");
		System.out.println("**********************************************************");
		System.out.println();
        System.out.println(" -> Select an option : ");
        System.out.println();
        System.out.println(" 1) Login");
        System.out.println(" 2) Registration");
        System.out.println(" 3) Calculate eBill");
        System.out.println(" 4) Exit");
    }

    static String getChoice(Scanner scanner) {
    	System.out.println();
    	System.out.print(" -> Enter your choice : ");
        return scanner.nextLine().toLowerCase();
    }

    static void handleMainMenuChoice(String choice, Scanner scanner) {
        switch (choice) {
            case "login":
            case "1":
                LoginMenu.handleLoginChoice(scanner);
                break;
            case "registration":
            case "2":
                LoginMenu.performUserRegistration(scanner);
                break;
            case "calculate ebill":
            case "3":
                CalculateEbill.calculateEbill();
                break;
            case "exit":
            case "4":
                handleExitOption(scanner);
                break;
            default:
            	System.out.println();
                System.err.println(" Invalid choice. Please select either Login, Registration, Calculate eBill, or Exit.");
        }
    }

    private static void handleExitOption(Scanner scanner) {
    	System.out.println();
    	System.out.println("*---- EXIT ----*");
    	System.out.println();
        System.out.println(" -> Do you really want to exit ? ");
        System.out.print(" -> Yes/1 OR No/0 : ");
        System.out.print("");
        String exitConfirmation = scanner.nextLine().toLowerCase();
        System.out.println();

        if (YES_OPTION.equals(exitConfirmation) || "1".equals(exitConfirmation)) {
    		System.out.println();
    		System.out.println("**********************************************************");
    		System.out.println("*----------------- EXITING THE SYSTEM -------------------*");
    		System.out.println("*-----------------  HAVE A NICE DAY ! -------------------*");
    		System.out.println("**********************************************************");
    		System.out.println();
    		
            System.exit(0);
        } else if (NO_OPTION.equals(exitConfirmation) || "0".equals(exitConfirmation)) {

        } else {
            System.out.println("Invalid input. Please select either yes/1 or no/0.");
        }
    }
}